import java.util.ArrayList;

class Client {	//���� Ŭ����
	String name, number, designer, hairShape;
	int time, date;

	public Client(String name, String number, int time, String designer, String hairShape, int date) {
		this.name = name;
		this.number = number;
		this.time = time;
		this.designer = designer;
		this.hairShape = hairShape;
		this.date = date;
	}
}
class ClientManager {
	public static ArrayList<Client> list = new ArrayList<Client>();
}

class Designer {
	String name, number;
	int starttime, endtime, date;
	// ArrayList<Client> s = new ArrayList<Client>();
	public Designer(String name, int starttime, int endtime,String number) {
		this.name = name;
		this.number = number;
		this.starttime = starttime;
		this.endtime = endtime;
	}
}
class DesignerManager {
	public static ArrayList<Designer> list = new ArrayList<Designer>();
}